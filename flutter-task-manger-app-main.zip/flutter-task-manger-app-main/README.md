# A Flutter To-do list Application using sqlite

This is a simple application to help you create tasks and set reminders to increase your productivity.
All the data is stored locally using SQlite.

## Screeenshots
![](images/Z943GK9yDmwj_1024_500.png)
