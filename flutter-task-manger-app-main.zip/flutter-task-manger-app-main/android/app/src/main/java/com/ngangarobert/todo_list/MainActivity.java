package com.ngangarobert.todo_list;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
