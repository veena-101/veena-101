package com.tnsif.student;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B76StudentApplication 
{

	public static void main(String[] args)
	{
		SpringApplication.run(B76StudentApplication.class, args);
	}

}
