package com.tnsif.student;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="student")
//to indicate this class as Entity
public class Student
{
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
private String name;
private Long semester;

public Student() {
	super();
}


public Student( String name, Long semester) 
{
	super();
	

	this.name = name;
	this.semester = semester;
	
}
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Long getSemester() {
	return semester;
}
public void setSemester(Long semester) {
	this.semester = semester;
}
@Override
public String toString() {
	return "Student [id=" + id + ", name=" + name + ", semester=" + semester + ", getId()=" + getId() + ", getName()="
			+ getName() + ", getSemester()=" + getSemester() + ", getClass()=" + getClass() + ", hashCode()="
			+ hashCode() + ", toString()=" + super.toString() + "]";
}





}
