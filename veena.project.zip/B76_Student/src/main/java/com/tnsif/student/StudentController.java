package com.tnsif.student;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController 
{
   @Autowired
	private StudentService service;
   
 //Retrieval
 	@GetMapping("/student")
 	public List<Student> list(){
 		return service.listAll();
 	}
 	
 	//Retrieval by id
 	@GetMapping("/student/{id}")
 	public ResponseEntity <Student> get(@PathVariable Integer id){
 		try {
 			Student student = service.get(id);
 			return new ResponseEntity<Student>(student,HttpStatus.OK);
 		} 
 		catch (Exception e) {
 			return new ResponseEntity<Student>(HttpStatus.NOT_FOUND);
 		}
 	}
 	
 	//create
 	@PostMapping("/student")
 	public Student add(@RequestBody Student student) {
 		return service.save(student);
 	}
 	
 	//update
 	@PutMapping("/student/{id}")
 	public Student update(@RequestBody Student student,@PathVariable Long id)
 	{
 		student.setId(id);
 		return service.save(student);
 	}
 	
 	//delete
 	@DeleteMapping("/student/{id}")
 	public void delete (@PathVariable Integer id) {
 		service.delete(id);
 	}
}
